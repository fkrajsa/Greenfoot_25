import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Domaci_Ukol_PROG-1B1
 * 
 * @author Filip Krajsa 
 * @version v1
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        Brouk brouk1 = new Brouk();
        int x1 = Greenfoot.getRandomNumber(getWidth());
        int y1 = Greenfoot.getRandomNumber(getHeight());
        addObject(brouk1, x1, y1);
        
        Brouk brouk2 = new Brouk();
        addObject(brouk2,
        Greenfoot.getRandomNumber(getWidth()),
        Greenfoot.getRandomNumber(getHeight())
        );
        Brouk brouk3 = new Brouk();
        addObject(brouk3,
        Greenfoot.getRandomNumber(getWidth()),
        Greenfoot.getRandomNumber(getHeight())
        );   
        
    }
    
}
