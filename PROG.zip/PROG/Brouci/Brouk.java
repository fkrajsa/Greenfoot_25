import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Domaci_Ukol_PROG-1B1
 * 
 * @author Filip Krajsa 
 * @version v1
 */
public class Brouk extends Actor
{
    private int kroky;
    private int rychlost;
    public Brouk(){
        kroky = 0;
        rychlost = Greenfoot.getRandomNumber(5) + 2; //rychlost od 2 do 6
    }
    public void act()
    {
        if (kroky > 0){
            move(rychlost);
            kroky--;
        }
       else{
            turn(Greenfoot.getRandomNumber(360));
            kroky = Greenfoot.getRandomNumber(31) + 10; //kroky od 10 - 40
        }
    }
}
