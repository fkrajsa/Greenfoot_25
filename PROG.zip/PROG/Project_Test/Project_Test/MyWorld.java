import greenfoot.*;  

public class MyWorld extends World
{
    private int spawnCounter = 0;
    public MyWorld()
    {    
        super(600, 400, 1);
        prepare();

    }

    private void prepare()
    {
        Hrac hrac = new Hrac();
        addObject(hrac, 50, 200); // start uprostřed výšky
    }

    public void act() {
        spawnCounter++;

        if (spawnCounter % 50 == 0) {
            // spawn 3 mincí najednou
            for (int i = 0; i < 3; i++) {
                addObject(new Mince(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
            }

            // spawn 2 nepřátel najednou
            for (int i = 0; i < 2; i++) {
                addObject(new Nepritel(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
            }
        }

    }

}
