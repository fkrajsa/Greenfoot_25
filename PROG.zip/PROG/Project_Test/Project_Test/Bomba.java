import greenfoot.*;

public class Bomba extends Actor
{
    private int speed = 3;

    public void act()
    {
        // letí z prava doleva
        setLocation(getX() - speed, getY());
        // remove objektu 
        if (getX() <= 0) {
            getWorld().removeObject(this);
        }
    }
}
