import greenfoot.*;

public class Hrac extends Actor
{
    private int speed = 2;
    public void act() 
    {
        pohyb();
        sbirejMince();
        kontrolujKolize();
    }

    private void pohyb() {
        int x = getX() + speed;
        int y = getY();
        // pohyb nahoru
        if (Greenfoot.isKeyDown("up") && getY() > 0) 
        {
            y -= 5;
        }
        // pohyb dolů
        if (Greenfoot.isKeyDown("down") && getY() < getWorld().getHeight()) 
        {
            y += 5;
        }
        // vrácení zpět
        if (x > getWorld().getWidth()) 
        {
            x = 0;
        }
        if (x < 0) 
        {
            x = getWorld().getWidth();
        }
        // konečné nastavení pozice
        setLocation(x, y);
    }

    private void sbirejMince() {
        Mince mince = (Mince) getOneIntersectingObject(Mince.class);
        if (mince != null) {
            getWorld().removeObject(mince);
        }
    }

    private void kontrolujKolize() {
        Nepritel nepritel = (Nepritel) getOneIntersectingObject(Nepritel.class);
        if (nepritel != null) {
            getWorld().removeObject(nepritel);
        }

    }
}
