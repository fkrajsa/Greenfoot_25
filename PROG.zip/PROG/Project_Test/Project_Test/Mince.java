import greenfoot.*;

public class Mince extends Actor
{
    private int rychlost;

    public void act() 
    {
        rychlost = Greenfoot.getRandomNumber(3);
        // pohyb doleva
        setLocation(getX() - rychlost, getY());

        // pokud dojde na levý okraj, odstraní se
        if (getX() <= 0) {
            getWorld().removeObject(this);
        }
    }
}

