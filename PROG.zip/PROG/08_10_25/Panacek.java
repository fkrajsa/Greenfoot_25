import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Panacek here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Panacek extends Actor
{
    // Atributy třídy:
  //  private int rychlost;
    private int pocetKroku = 0;
   // public Panacek()
   // {
     //   rychlost = Greenfoot.getRandomNumber(4) + 1;
        //do atributu rychlost uložím náhodné čislo 1-5
//    }
    
    public void act()
    {
        pocetKroku++;
        if(pocetKroku > 50);{
            pocetKroku = 0;
            turn(90);
        }
        move(5);
    }
}
//vytvořit tridu ctverec a tento kod v ni
