import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author Filip Krajsa 
 * @version 08_10_2025
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        Panacek panacek = new Panacek();
        //proměnná na nastavení random pozice
        //proměnná - podobné jako atribut
        int x1 =  Greenfoot.getRandomNumber(getWidth());
        int y1 = Greenfoot.getRandomNumber(getHeight());
        addObject(panacek,300,200);
        
      //Panacek panacekdva = new Panacek();
      //addObject(panacekdva, x1,y1 );
        
       //Panacek panacektri = new Panacek();
       //addObject(panacektri, x1, y1);
    }
}
