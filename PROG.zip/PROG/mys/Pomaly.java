import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Pomaly extends Actor
{
    private int rychlost = 10;
    private int rotace;
    public Pomaly()
    {
        rotace = Greenfoot.getRandomNumber(180);
    }
    public void act()
    {
        move(rychlost);
        if(isAtEdge())
        {
            turn(rotace);
        }
        MouseInfo mys = Greenfoot.getMouseInfo();
        if (mys !=null)
        {
            int mysX = mys.getX();
            int mysY = mys.getY();
            this.turnTowards(mysX, mysY);
            this.move(3);;
        }
    }
}
