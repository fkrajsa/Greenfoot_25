import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    private int x;
    private int y;
    public MyWorld()
    
    {    
        super(600, 400, 1);
        x = Greenfoot.getRandomNumber(599);
        y = Greenfoot.getRandomNumber(399);
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        Vcela v1 = new Vcela();
        addObject(v1, x, y);
        Linux l1 = new Linux();
        addObject(l1, x/2, y/2);
        Linux l2 = new Linux();
        addObject(l2, x/3, y/3);
        Linux l3 = new Linux();
        addObject(l3, x/4, y/4);
        
        
    }
}
