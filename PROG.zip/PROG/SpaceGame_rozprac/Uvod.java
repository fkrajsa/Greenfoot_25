import greenfoot.*;
/**
 * Úvodní obrazovka
 * 
 * @author Filip Krajsa 
 * @version Rozpracovana
 */
public class Uvod extends World
{
    public Uvod()
    {    
        super(800, 600, 1); 
    }

    public void act()
    {
        if (Greenfoot.isKeyDown("s"))
        {
            Greenfoot.setWorld(new MyWorld());
        }
    }

}
