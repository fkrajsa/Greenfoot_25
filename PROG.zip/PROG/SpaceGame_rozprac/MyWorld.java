import greenfoot.*;
/**
 * Kód herního světa
 * 
 * @author Filip Krajsa 
 * @version Rozpracovana
 */
public class MyWorld extends World
{
    public int body = 0;
    public int zivoty = 10;
    public int maxZivoty = 10;
    public int zasahy = 0;
    private int citac = 0;
    public MyWorld()
    {    
        super(800, 600, 1);
        prepare();
    }

    private void prepare()
    {
        Hrac hrac = new Hrac();
        addObject(hrac, 50, getHeight() / 2);
    }

    public void act() {
        citac++;
        //spawn mince a nepritele kazdych 50 fps hry
        if (citac % 50 == 0) {
            addObject(new Mince(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
            addObject(new Nepritel(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
        }
        
        if (citac % (60 * 7) == 0) {
            addObject(new Stesti(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
        }

        if (citac % 80  == 0) 
        {
            addObject(new Bomba(), getWidth(), Greenfoot.getRandomNumber(getHeight()));            
        }
    }

    public void pridejBody(int kolik) {
        body += kolik;
        if (body >= 10) {
            Greenfoot.stop();
            showText("Vyhrál jsi!", getWidth()/2, getHeight()/2);
        }
    }

    public void uberZivot() {
        zivoty--;
        if (zivoty <= 0) {
            Greenfoot.stop();
            showText("Prohrál jsi!", getWidth()/2, getHeight()/2);
        }
    }

    public void dotekBomby()
    {
        Greenfoot.stop();
        showText("Vybouchl jsi!", getWidth()/2, getHeight()/2);
    }

    public void pridejZasah() {
        zasahy++;
    }
    
    public void resetZdravi()
    {
        zivoty = 10;
    }
}
