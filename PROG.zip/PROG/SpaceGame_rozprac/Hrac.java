import greenfoot.*;
/**
 * Kód hráče
 * 
 * @author Filip Krajsa 
 * @version Rozpracovana
 */
public class Hrac extends Actor
{
    private int rychlost = 2;

    public void act() 
    {
        pohyb();
        sbirejMince();
        kontrolujNepritele();
        kontrolujBombu();
        kontrolujZdravi();
        zrychli();
        resetHry();
        if (Greenfoot.isKeyDown("space")) {
            vystrel();
        }
    }

    private void pohyb() {
        int x = getX() + rychlost;
        int y = getY();
        if (Greenfoot.isKeyDown("up") && y > 0) 
        {
            y -= 5;
        }
        if (Greenfoot.isKeyDown("down") && y < getWorld().getHeight()) 
        {
            y += 5;
        }
        if (x > getWorld().getWidth()) 
        {
            x = 0;
        }
        if (x < 0) 
        {
            x = getWorld().getWidth();
        }
        setLocation(x, y);
    }

    private void vystrel() {
        Strela s = new Strela();
        getWorld().addObject(s, getX() + 30, getY());
    }

    private void sbirejMince() {
        Mince m = (Mince)getOneIntersectingObject(Mince.class);
        if (m != null) {
            getWorld().removeObject(m);
            ((MyWorld)getWorld()).pridejBody(1);
        }
    }

    private void kontrolujNepritele() {
        Nepritel n = (Nepritel)getOneIntersectingObject(Nepritel.class);
        if (n != null) {
            getWorld().removeObject(n);
            ((MyWorld)getWorld()).uberZivot();
        }
    }

    private void kontrolujBombu() 
    {
        Bomba b = (Bomba)getOneIntersectingObject(Bomba.class);
        if (b != null) {
            getWorld().removeObject(b);
            ((MyWorld)getWorld()).dotekBomby();
            this.removeTouching(Bomba.class);
        }
    }

    private void kontrolujZdravi()
    {
        Stesti s = (Stesti)getOneIntersectingObject(Stesti.class);
        if (s != null)
        {
            getWorld().removeObject(s);
            ((MyWorld)getWorld()).resetZdravi();
            this.removeTouching(Stesti.class);
        }
    }
    
    private void zrychli()
    {
        if (Greenfoot.isKeyDown("right"))
        {
            this.move(rychlost * 2);
        }
    }
    
    private void resetHry()
    {
        if (Greenfoot.isKeyDown("r"))
        {
           Greenfoot.setWorld(new MyWorld());
        }
    }
}
