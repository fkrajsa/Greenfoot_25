import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Stesti extends Actor
{
    private int rychlost = 2;
    public void act()
    {
        setLocation(getX() - rychlost, getY());

        if (getX() <= 0) {
            getWorld().removeObject(this);
            
        }
    }
}
