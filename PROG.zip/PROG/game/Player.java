import greenfoot.*;

/**
 * Hráč ovládaný šipkami nebo myší. Umí střílet.
 */
public class Player extends Actor
{
    private int health = 5; // atribut - životy
    private int speed = 4;  // atribut - rychlost
    private int shootCooldown = 0; // pomocná proměnná
    
    public Player() {
        GreenfootImage img = new GreenfootImage(30,30);
        img.setColor(java.awt.Color.BLUE);
        img.fillOval(0,0,30,30);
        setImage(img);
    }
    
    public void act() 
    {
        // ovládání klávesami (větvení & použití getWidth/getHeight v něčem jiném)
        if (Greenfoot.isKeyDown("left")) {
            setLocation(Math.max(0, getX()-speed), getY());
        } 
        if (Greenfoot.isKeyDown("right")) {
            setLocation(Math.min(getWorld().getWidth()-1, getX()+speed), getY());
        }
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), Math.max(0, getY()-speed));
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), Math.min(getWorld().getHeight()-1, getY()+speed));
        }
        
        // střelba myší nebo mezerník
        if (Greenfoot.mouseClicked(null) || Greenfoot.isKeyDown("space")) {
            if (shootCooldown <= 0) {
                shoot();
                shootCooldown = 15;
            }
        }
        if (shootCooldown > 0) shootCooldown--;
        
        // kolize s nepřítelem
        Enemy e = (Enemy)getOneIntersectingObject(Enemy.class);
        if (e != null) {
            // větvení: pokud máme štít (nebo ne)
            if (health > 0) {
                health--;
                getWorld().removeObject(e);
                if (health <= 0) {
                    getWorld().removeObject(this);
                }
            }
        }
    }
    
    private void shoot() {
        // vytvoříme projektil mířicí na pozici myši, nebo pokud není myš, nahoru
        MouseInfo mi = Greenfoot.getMouseInfo();
        Bullet b = new Bullet();
        if (mi != null) {
            int mx = mi.getX();
            int my = mi.getY();
            // vypočítáme směr
            double dx = mx - getX();
            double dy = my - getY();
            b.setDirectionVector(dx, dy);
        } else {
            b.setDirectionVector(0, -1); // default nahoru
        }
        getWorld().addObject(b, getX(), getY());
    }
}