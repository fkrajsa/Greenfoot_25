import greenfoot.*; 
import java.util.List;

/**
 * Hlavní svět - intro obrazovka i herní svět.
 */
public class MyWorld extends World
{
    private int spawnCooldown = 0;
    private int score = 0;
    private boolean inGame = false;
    private GreenfootImage bg;
    
    public MyWorld()
    {    
        // Velikost scény 800x600, 1x1 cell
        super(800, 600, 1); 
        bg = new GreenfootImage(getWidth(), getHeight());
        setBackground(bg);
        showIntro();
    }
    
    public void showIntro() {
        removeObjects(getObjects(null));
        getBackground().clear();
        getBackground().drawString("Klikni myší nebo stiskni ENTER pro start\\n" +
            "Ovládání: šipky = pohyb, mezerník = střelba, nebo myš klik", 60, 100);
        getBackground().drawString("Cíl: Sbírej body, vyhýbej se nepřátelům a střílej je.", 60, 140);
        getBackground().drawString("Hra obsahuje: větvení (if), cyklus for, kolize, atributy, getWidth/getHeight().", 60, 180);
        inGame = false;
    }
    
    public void startGame() {
        removeObjects(getObjects(null));
        getBackground().clear();
        Player p = new Player();
        addObject(p, getWidth()/2, getHeight()/2);
        score = 0;
        spawnCooldown = 0;
        inGame = true;
        addObject(new HUD(), 100, 20);
    }
    
    public void act() {
        if (!inGame) {
            if (Greenfoot.mouseClicked(null) || Greenfoot.isKeyDown("enter")) {
                startGame();
            }
            return;
        }
        
        // každých ~90 ticků spawnuj nepřátele
        if (spawnCooldown <= 0) {
            spawnEnemies(3); // použijeme cyklus for při spawnování
            spawnCooldown = 90;
        } else {
            spawnCooldown--;
        }
        
        // jednoduché zvýšení obtížnosti podle skóre
        if (score > 20) {
            // větvení (if) - zrychlí spawn
            if (spawnCooldown > 60) spawnCooldown = 60;
        }
        
        // konec hry pokud hráč není na světě
        List<Player> players = getObjects(Player.class);
        if (players.isEmpty()) {
            // game over zobrazit
            getBackground().drawString("GAME OVER - klikni pro restart", getWidth()/2 - 80, getHeight()/2);
            inGame = false;
        }
    }
    
    // spawnEnemies ukazuje použití cyklu for
    public void spawnEnemies(int count) {
        for (int i = 0; i < count; i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            // zajistíme spawn mimo hráče (větvení)
            Player p = getObjects(Player.class).isEmpty() ? null : getObjects(Player.class).get(0);
            if (p != null) {
                // pokud by spawn byl příliš blízko hráče, posuň
                if (Math.abs(x - p.getX()) < 100 && Math.abs(y - p.getY()) < 100) {
                    // posunout na okraj (použití getWidth/getHeight)
                    if (x < getWidth()/2) x = getWidth() - 20; else x = 20;
                    if (y < getHeight()/2) y = getHeight() - 20; else y = 20;
                }
            }
            addObject(new Enemy(), x, y);
        }
    }
    
    public void addScore(int s) {
        score += s;
        // najdi HUD a aktualizuj ho
        HUD hud = getObjects(HUD.class).isEmpty() ? null : getObjects(HUD.class).get(0);
        if (hud != null) hud.update(score);
    }
    
    public int getScore() { return score; }
}