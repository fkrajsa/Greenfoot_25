import greenfoot.*;

/**
 * Projektil, který se pohybuje konstantní rychlostí po směru.
 */
public class Bullet extends Actor
{
    private double vx = 0;
    private double vy = -4;
    private int life = 120; // pomocná proměnná
    
    public Bullet() {
        GreenfootImage img = new GreenfootImage(6,6);
        img.setColor(java.awt.Color.BLACK);
        img.fillOval(0,0,6,6);
        setImage(img);
    }
    
    public void setDirectionVector(double dx, double dy) {
        double len = Math.sqrt(dx*dx + dy*dy);
        if (len == 0) { vx = 0; vy = -4; return; }
        vx = dx / len * 6;
        vy = dy / len * 6;
    }
    
    public void act() {
        setLocation(getX() + (int)Math.round(vx), getY() + (int)Math.round(vy));
        life--;
        // kolize s nepřítelem
        Enemy e = (Enemy)getOneIntersectingObject(Enemy.class);
        if (e != null) {
            getWorld().removeObject(e);
            getWorld().removeObject(this);
            // zvýšit skóre přes svět (ukázka využití atributů světa)
            MyWorld mw = (MyWorld)getWorld();
            mw.addScore(1);
            return;
        }
        // pokud projektil mimo okraj, odstranit
        if (getX() < 0 || getY() < 0 || getX() > getWorld().getWidth() || getY() > getWorld().getHeight() || life <= 0) {
            getWorld().removeObject(this);
        }
    }
}