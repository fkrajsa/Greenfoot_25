import greenfoot.*;

/**
 * Heads-up display, vykresluje skóre.
 */
public class HUD extends Actor
{
    private int score = 0;
    public HUD() {
        update(0);
    }
    public void update(int s) {
        score = s;
        GreenfootImage img = new GreenfootImage(200,40);
        img.clear();
        img.setColor(java.awt.Color.WHITE);
        img.drawString("Skóre: " + score, 10, 20);
        setImage(img);
    }
    public void act() {
        // HUD je statický
    }
}