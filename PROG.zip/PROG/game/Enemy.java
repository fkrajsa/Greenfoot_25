import greenfoot.*;

/**
 * Jednoduchý nepřítel, který hledá hráče.
 */
public class Enemy extends Actor
{
    private int speed = 2; // atribut
    public Enemy() {
        GreenfootImage img = new GreenfootImage(20,20);
        img.setColor(java.awt.Color.RED);
        img.fillOval(0,0,20,20);
        setImage(img);
    }
    
    public void act() {
        World w = getWorld();
        if (w == null) return;
        Player p = (Player)w.getObjects(Player.class).isEmpty() ? null : (Player)w.getObjects(Player.class).get(0);
        if (p != null) {
            // pohyb směrem k hráči (použití větvení a aritmetiky)
            int px = p.getX();
            int py = p.getY();
            int ex = getX();
            int ey = getY();
            double dx = px - ex;
            double dy = py - ey;
            double dist = Math.sqrt(dx*dx + dy*dy);
            if (dist > 0) {
                setLocation(ex + (int)Math.round(dx/dist*speed), ey + (int)Math.round(dy/dist*speed));
            }
        } else {
            // když není hráč, mírně bloudí (ukázka if)
            if (Greenfoot.getRandomNumber(100) < 5) {
                setLocation(getX() + Greenfoot.getRandomNumber(11)-5, getY() + Greenfoot.getRandomNumber(11)-5);
            }
        }
    }
}