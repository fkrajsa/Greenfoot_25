import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mys here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mys extends Actor
{
    /**
     * Act - do whatever the Mys wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        MouseInfo mi = Greenfoot.getMouseInfo();
        if (mi !=null)
        {
            int miX = mi.getX();
            int miY = mi.getY();
            // Přesuň se na kurzor myši
            //setLocation(miX , miY);
            // Otoč se směrem k myši
            turnTowards(miX , miY);
            // Posuň se směrem k myši
            move(2);
        }
    }
}
