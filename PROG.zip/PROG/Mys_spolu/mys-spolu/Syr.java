import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Syr here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Syr extends Actor
{
    /**
     * Act - do whatever the Syr wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        //jakmile se dotkne, přesune se jinam ve světě
        if (isTouching(Mys.class))
        {
            World world = getWorld();
            /*int x = Greenfoot.getRandomNumber(world.getWidth());
            int y = Greenfoot.getRandomNumber(world.getHeight());
            setLocation(x, y);
           */ //jakmile se dotkne, sýr zmizí
            world.removeObject(this);
        }
    }
}   