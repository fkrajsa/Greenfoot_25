import greenfoot.*;
/**
 * Kód herního světa
 * 
 * @author Filip Krajsa 
 * @version Finalni
 */
public class MyWorld extends World
{
    public int body = 0;
    public int zivoty = 10;
    public int maxZivoty = 10;
    public int zasahy = 0;
    private int citac = 0;
    public MyWorld()
    {    
        super(800, 600, 1);
        prepare();
        aktualizujText();
    } 
    private void prepare()
    {   
        //Přidání hvězd do pozadí
        for (int i = 0; i < 50; i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Hvezda(), x, y); 
        }
        //Přidání hráče (rakety)
        Hrac hrac = new Hrac();
        addObject(hrac, 50, getHeight() / 2);
    }

    public void act() {
        citac++;
        //Spawn nepřítele, mince, lékárničky a bomby dané FPS
        if (citac % 50 == 0) {
            addObject(new Mince(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
            addObject(new Nepritel(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
        }

        if (citac % (60 * 5) == 0) {
            addObject(new Bomba(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
        }

        if (citac % (60 * 7) == 0) {
            addObject(new Stesti(), getWidth(), Greenfoot.getRandomNumber(getHeight()));
        }
    }

    public void pridejBody(int kolik) {
        body += kolik;
        aktualizujText();

        if (body == 10) {
            Greenfoot.playSound("vyhra.wav");
            showText("Vyhrál jsi!", getWidth()/2, getHeight()/2);
            Greenfoot.delay(100);
            Greenfoot.setWorld(new Uvod());
        }
    }

    public void uberZivot() {
        zivoty--;
        aktualizujText();

        if (zivoty == 0) {
            Greenfoot.playSound("prohra.wav");
            showText("Prohrál jsi!", getWidth()/2, getHeight()/2);
            Greenfoot.delay(100);
            Greenfoot.setWorld(new Uvod());
        }
    }

    public void doplnZivoty() {
        zivoty = maxZivoty;
        aktualizujText();
    }

    public void okamzitaSmrt() {
        Greenfoot.playSound("exploze.wav");
        showText("Vybouchl jsi!", getWidth()/2, getHeight()/2);
        Greenfoot.delay(100);
        Greenfoot.setWorld(new Uvod());
    }

    public void pridejZasah() {
        zasahy++;
        aktualizujText();
    }

    public void aktualizujText() {
        showText("Životy: " + zivoty + " | Body: " + body + " | Zásahy: " + zasahy, 180, 20);
    }

}
