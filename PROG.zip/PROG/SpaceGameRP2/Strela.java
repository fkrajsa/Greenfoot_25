import greenfoot.*;
/**
 * Střela
 * 
 * @author Filip Krajsa 
 * @version Finalni
 */
public class Strela extends Actor
{
    private int rychlost = 6;

    public void act() 
    {
        setLocation(getX() + rychlost, getY());

        if (getX() >= getWorld().getWidth() -1) {
            getWorld().removeObject(this);
            return;
        }

        Nepritel n = (Nepritel)getOneIntersectingObject(Nepritel.class);

        if (n != null) {
            getWorld().removeObject(n);
            ((MyWorld)getWorld()).pridejZasah();
            getWorld().removeObject(this);
        }
    }
}
