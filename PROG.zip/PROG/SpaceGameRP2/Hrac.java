import greenfoot.*;
/**
 * Kód hráče
 * 
 * @author Filip Krajsa 
 * @version Finalni
 */
public class Hrac extends Actor
{
    private int rychlost = 2;

    public void act() 
    {
        pohyb();
        sbirejMince();
        kontrolujNepritele();
        kontrolujBombu();
        kontrolujStesti();
        zrychli();
        if (Greenfoot.isKeyDown("space")) {
            vystrel();
        }
    }

    private void pohyb() {
        //Neustálý pohyb dopředu
        int x = getX() + rychlost;
        int y = getY();
        //Pohyb nahoru a dolů
        if (Greenfoot.isKeyDown("up") && y > 0) 
        {
            y -= 5;
        }
        if (Greenfoot.isKeyDown("down") && y < getWorld().getHeight()) 
        {
            y += 5;
        }
        //Nekonečnost světa
        if (x > getWorld().getWidth()) 
        {
            x = 0;
        }
        setLocation(x, y);
    }

    private void vystrel() {
        Strela s = new Strela();
        getWorld().addObject(s, getX() + 30, getY());
        Greenfoot.playSound("strela.wav");
    }

    private void sbirejMince() {
        //Kontrola nárazu s mincí
        Mince m = (Mince)getOneIntersectingObject(Mince.class);
        if (m != null) {
            getWorld().removeObject(m);
            ((MyWorld)getWorld()).pridejBody(1);
            Greenfoot.playSound("mince.wav");
        }
    }

    private void kontrolujNepritele() {
        Nepritel n = (Nepritel)getOneIntersectingObject(Nepritel.class);
        if (n != null) {
            getWorld().removeObject(n);
            ((MyWorld)getWorld()).uberZivot();
        }
    }

    private void kontrolujBombu() {
        Bomba b = (Bomba)getOneIntersectingObject(Bomba.class);
        if (b != null) {
            ((MyWorld)getWorld()).okamzitaSmrt();
        }
    }

    private void kontrolujStesti() {
        Stesti s = (Stesti)getOneIntersectingObject(Stesti.class);
        if (s != null) {
            getWorld().removeObject(s);
            ((MyWorld)getWorld()).doplnZivoty();
            Greenfoot.playSound("zdravi.wav");
        }
    }
    private void zrychli() 
    {
        if( Greenfoot.isKeyDown("right")) 
        {
            move(5);
        }
    }
}
