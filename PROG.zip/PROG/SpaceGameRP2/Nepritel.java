import greenfoot.*;
/**
 * Nepřítel (meteorit)
 * 
 * @author Filip Krajsa 
 * @version Finalni
 */
public class Nepritel extends Actor
{
    private int rychlost = 2;

    public void act() 
    {
        setLocation(getX() - rychlost, getY());

        if (getX() <= 0) {
            getWorld().removeObject(this);
        }
    }
}
